package com.fleetManagement.util;

//·��������

public class PathUtils {

    public static String getIconImgPath() {
        return "D:\\JAVACODE\\fleetManagement\\icon.jpg";
    }

}
